package com.oxide.companion

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 14)
    private val panel = Color.rgb(25, 25, 29)
    private val red = Color.rgb(220, 35, 43)
    private val white = Color.rgb(245, 245, 245)
    private val muted = Color.rgb(165, 165, 172)
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("oxide_settings", MODE_PRIVATE) }
    private val pickApk = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun base(title: String, subtitle: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.oxide_logo)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label(title, 23f, white, true))
        titles.addView(label(subtitle, 12f, muted, false))
        header.addView(logo)
        header.addView(space(12))
        header.addView(titles)
        root.addView(header)
        root.addView(space(22))
    }

    private fun showHome() {
        base("OXIDE COMPANION", "FIELD TOOLKIT  •  VERSION 0.1.0")
        card("Добро пожаловать") {
            addView(label("Твой игровой компаньон.", 18f, white, true))
            addView(space(6))
            addView(label("Настройки, локальные конфиги, справочник и безопасная диагностика APK.", 14f, muted))
        }
        root.addView(space(14))
        navButton("⚙  Настройки и конфиги") { showSettings() }
        navButton("▤  Игровой справочник") { showGuide() }
        navButton("⌕  Диагностика APK") { showDiagnostics() }
        root.addView(space(12))
        root.addView(label("Локальная версия • Данные хранятся на устройстве", 11f, muted))
    }

    private fun showSettings() {
        base("НАСТРОЙКИ", "ЛОКАЛЬНЫЕ ПАРАМЕТРЫ ПРИЛОЖЕНИЯ")
        card("Внешний вид") {
            addView(label("Тема: Dark / Black Red", 15f, white, true))
            addView(label("Акцент интерфейса — красный. Настройка темы будет расширена позже.", 12f, muted))
        }
        root.addView(space(12))
        card("Параметры") {
            toggle("Компактные карточки", "compact")
            toggle("Показывать подсказки", "tips", true)
            toggle("Виброотклик", "haptics")
        }
        root.addView(space(12))
        card("Конфиги") {
            addView(label("Профиль хранится локально в настройках Android.", 13f, muted))
            val row = LinearLayout(this)
            row.addView(actionButton("Экспорт JSON") { exportConfig() }, LinearLayout.LayoutParams(0, dp(48), 1f))
            row.addView(space(8))
            row.addView(actionButton("Сбросить") {
                prefs.edit().clear().apply()
                toast("Настройки сброшены")
                showSettings()
            }, LinearLayout.LayoutParams(0, dp(48), 1f))
            addView(row)
        }
        backButton()
    }

    private fun toggle(title: String, key: String, default: Boolean = false) {
        val sw = Switch(this).apply {
            text = title
            textSize = 14f
            setTextColor(white)
            isChecked = prefs.getBoolean(key, default)
            buttonTintList = android.content.res.ColorStateList.valueOf(red)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        addView(sw)
    }

    private fun showGuide() {
        base("СПРАВОЧНИК", "КРАТКИЕ ПОЛЕЗНЫЕ ЗАМЕТКИ")
        val entries = listOf(
            "Выживание" to "Следи за запасами еды, воды и медикаментов. Не носи весь лут с собой без необходимости.",
            "Подготовка к вылазке" to "Перед выходом проверь экипировку, свободное место и маршрут возвращения.",
            "Инвентарь" to "Сортируй предметы по назначению и оставляй запас места для найденных ресурсов.",
            "Безопасность аккаунта" to "Не устанавливай неизвестные модифицированные APK и не передавай данные входа третьим лицам."
        )
        entries.forEach { (title, body) ->
            card(title) { addView(label(body, 14f, muted)) }
            root.addView(space(10))
        }
        backButton()
    }

    private fun showDiagnostics() {
        base("ДИАГНОСТИКА APK", "АНАЛИЗ ВЫБРАННОГО ФАЙЛА")
        card("Проверка приложения") {
            addView(label("Выбери APK через системный файловый менеджер. Oxide Companion прочитает базовые сведения о пакете и не будет устанавливать или изменять его.", 13f, muted))
            addView(space(12))
            addView(actionButton("Выбрать APK") {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/vnd.android.package-archive"
                }
                startActivityForResult(intent, pickApk)
            })
            addView(space(12))
            addView(label("Результат появится здесь.", 12f, muted, false, "diagnostic_result"))
        }
        card("Что проверяется") {
            addView(label("• Читается ли APK как Android-пакет\n• Имя пакета и версия\n• Версия SDK, если доступна", 13f, muted))
            addView(space(6))
            addView(label("Это базовая проверка метаданных, а не антивирус и не гарантия безопасности файла.", 12f, red))
        }
        backButton()
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickApk && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val info = try {
                val tempApk = java.io.File(cacheDir, "selected-inspection.apk")
                contentResolver.openInputStream(uri)?.use { input ->
                    tempApk.outputStream().use { output -> input.copyTo(output) }
                }
                packageManager.getPackageArchiveInfo(tempApk.absolutePath, PackageManager.GET_ACTIVITIES)
                    .also { tempApk.delete() }
            } catch (_: Exception) { null }
            val result = if (info != null) {
                "APK распознан\nПакет: ${info.packageName}\nВерсия: ${info.versionName ?: "не указана"}\nSDK: ${info.applicationInfo?.minSdkVersion ?: "н/д"}"
            } else {
                "Не удалось прочитать метаданные APK. Файл может быть повреждён или иметь неподдерживаемый формат."
            }
            showDiagnostics()
            findViewById<TextView>(resources.getIdentifier("diagnostic_result", "id", packageName))?.text = result
            // Fallback: append result visibly if the generated view id is unavailable.
            root.addView(label(result, 13f, white))
        }
    }

    private fun exportConfig() {
        val obj = JSONObject()
        obj.put("compact", prefs.getBoolean("compact", false))
        obj.put("tips", prefs.getBoolean("tips", true))
        obj.put("haptics", prefs.getBoolean("haptics", false))
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_TEXT, obj.toString(2))
        }
        startActivity(Intent.createChooser(share, "Экспорт конфигурации"))
    }

    private fun backButton() {
        root.addView(space(16))
        root.addView(actionButton("←  На главную") { showHome() })
    }

    private fun navButton(text: String, click: () -> Unit) {
        root.addView(actionButton(text, click))
        root.addView(space(10))
    }

    private fun actionButton(text: String, click: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 14f
            isAllCaps = false
            setTextColor(white)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(panel)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), red)
            }
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { click() }
        }

    private fun card(title: String, content: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(panel)
                cornerRadius = dp(16).toFloat()
            }
        }
        box.addView(label(title, 16f, white, true))
        box.addView(space(8))
        box.content()
        root.addView(box)
    }

    private fun label(
        text: String, size: Float, color: Int, bold: Boolean = false, viewTag: String? = null
    ) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        if (viewTag != null) tag = viewTag
        setLineSpacing(dp(3).toFloat(), 1f)
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
