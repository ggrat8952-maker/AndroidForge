# Oxide Companion — starter project

Android companion app, Kotlin, native Android Views, dark/black-red style.

## Features in this starter
- Home menu and custom vector logo
- Local preferences stored in SharedPreferences
- Export of a small JSON config through Android share sheet
- Short survival-game reference section
- Basic APK metadata inspection for a user-selected APK via Android document picker

## Build on a phone
1. Install a maintained Android IDE/build environment from its official project/release page.
2. Import this folder as an existing Gradle Android project.
3. Install Android SDK Platform 36 and Build Tools if the IDE asks.
4. Use JDK 17 or 21 and Gradle 8.11.1.
5. Run the `app` debug build task (`assembleDebug`).

The former AndroidIDE project is archived and no longer maintained. Check the current status of any on-device IDE before installing it. AndroidIDE's own site points users toward Code on the Go as its successor:
https://androidide.com/

## Package
`com.oxide.companion`

## Notes
- This is source code, not a prebuilt APK.
- The APK diagnostic reads metadata only. It is not an antivirus scanner.
- The app does not inject into, modify, or read another game's process.
- The Android manifest requests no broad storage or network permissions.
